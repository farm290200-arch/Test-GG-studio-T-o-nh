
import React, { useState } from 'react';
import type { Settings, ImageModel } from '../types';
import { MODELS } from '../constants';

interface SettingsModalProps {
  currentSettings: Settings;
  onSave: (settings: Settings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ currentSettings, onSave, onClose }) => {
  const [selectedModel, setSelectedModel] = useState<ImageModel>(currentSettings.model);

  const handleSave = () => {
    onSave({ model: selectedModel });
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" onClick={onClose}>
      <div 
        className="bg-gray-800 border border-gray-700 rounded-xl shadow-2xl w-full max-w-md p-6 m-4"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-2xl font-bold mb-4">Cài đặt</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Mô hình tạo ảnh</label>
            <div className="space-y-2">
              {MODELS.map((model) => (
                <label 
                  key={model.id}
                  className={`flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedModel === model.id ? 'bg-purple-600/20 border-purple-500' : 'bg-gray-900 border-gray-600 hover:border-gray-500'
                  }`}
                >
                  <input
                    type="radio"
                    name="model"
                    value={model.id}
                    checked={selectedModel === model.id}
                    onChange={() => setSelectedModel(model.id)}
                    className="h-4 w-4 text-purple-600 bg-gray-700 border-gray-600 focus:ring-purple-500"
                  />
                  <span className="ml-3 text-sm font-medium text-white">{model.name}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-300 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
          >
            Hủy
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 text-sm font-medium text-white bg-purple-600 rounded-lg hover:bg-purple-700 transition-colors"
          >
            Lưu cài đặt
          </button>
        </div>
      </div>
    </div>
  );
};