
import React from 'react';
import { SettingsIcon, SparklesIcon } from './icons';

interface HeaderProps {
  onSettingsClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSettingsClick }) => {
  return (
    <header className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700 p-4 flex justify-between items-center sticky top-0 z-20">
      <div className="flex items-center gap-3">
        <SparklesIcon className="w-8 h-8 text-purple-400" />
        <h1 className="text-xl font-bold tracking-tight text-white">
          Gemini Image Studio <span className="text-purple-400">VN</span>
        </h1>
      </div>
      <button
        onClick={onSettingsClick}
        className="p-2 rounded-full hover:bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-gray-900"
        aria-label="Cài đặt"
      >
        <SettingsIcon className="w-6 h-6" />
      </button>
    </header>
  );
};