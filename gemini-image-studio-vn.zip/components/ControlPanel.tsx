
import React, { useState, useCallback, useEffect } from 'react';
import type { GenerationParams, ImageModel, AspectRatio } from '../types';
import { MODELS, STYLES, ASPECT_RATIOS } from '../constants';
import { fileToBase64 } from '../utils/imageUtils';
import { GenerateIcon, TrashIcon, UploadIcon } from './icons';

interface ControlPanelProps {
  onGenerate: (params: GenerationParams) => void;
  isLoading: boolean;
  model: ImageModel;
}

type Mode = 'generate' | 'edit' | 'fusion';

const modeLabels: Record<Mode, string> = {
  generate: 'Tạo mới',
  edit: 'Chỉnh sửa',
  fusion: 'Kết hợp',
};

export const ControlPanel: React.FC<ControlPanelProps> = ({ onGenerate, isLoading, model }) => {
  const [mode, setMode] = useState<Mode>('generate');
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [style, setStyle] = useState('Default');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 1000000));
  const [initImage, setInitImage] = useState<string | null>(null);
  const [maskImage, setMaskImage] = useState<string | null>(null);
  const [fusionImages, setFusionImages] = useState<string[]>([]);
  
  const selectedModel = MODELS.find(m => m.id === model);

  const handleFileChange = useCallback(async (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: React.Dispatch<React.SetStateAction<string | null>>
  ) => {
    if (e.target.files && e.target.files[0]) {
      const base64 = await fileToBase64(e.target.files[0]);
      setter(base64);
    }
  }, []);

  const handleFusionFilesChange = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const base64Promises = files.map(file => fileToBase64(file));
      const base64Results = await Promise.all(base64Promises);
      setFusionImages(prev => [...prev, ...base64Results].slice(0, 3));
    }
  }, []);
  
  const randomizeSeed = () => {
    setSeed(Math.floor(Math.random() * 1000000));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let finalPrompt = prompt;
    if (style !== 'Default') {
      finalPrompt = `${prompt}, ${style} style`;
    }
    
    let params: GenerationParams = {
        prompt: finalPrompt,
        negativePrompt,
        style,
        aspectRatio,
        seed,
        initImage: mode === 'edit' ? initImage : null,
        maskImage: mode === 'edit' ? maskImage : null,
        fusionImages: mode === 'fusion' ? fusionImages : [],
    };

    onGenerate(params);
  };
  
  const renderFileInput = (
    label: string, 
    image: string | null, 
    setter: React.Dispatch<React.SetStateAction<string | null>>,
    id: string
  ) => (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-400">{label}</label>
      {image ? (
        <div className="relative group">
          <img src={image} alt={label} className="rounded-lg w-full object-cover" />
          <button onClick={() => setter(null)} className="absolute top-2 right-2 p-1.5 bg-black/50 rounded-full text-white hover:bg-red-500 transition-colors opacity-0 group-hover:opacity-100">
            <TrashIcon className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <label htmlFor={id} className="cursor-pointer flex flex-col items-center justify-center w-full h-32 border-2 border-gray-600 border-dashed rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors">
          <UploadIcon className="w-8 h-8 text-gray-500 mb-2" />
          <p className="text-sm text-gray-500">Nhấn để tải lên</p>
          <input id={id} type="file" className="hidden" accept="image/*" onChange={(e) => handleFileChange(e, setter)} />
        </label>
      )}
    </div>
  );

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-4 sticky top-24">
      <div className="flex border-b border-gray-700 mb-4">
        {(['generate', 'edit', 'fusion'] as Mode[]).map(m => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={`capitalize py-2 px-4 text-sm font-medium transition-colors ${
              mode === m 
                ? 'border-b-2 border-purple-500 text-white' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {modeLabels[m]}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {mode === 'edit' && renderFileInput('Ảnh ban đầu', initImage, setInitImage, 'init-image-upload')}
        {mode === 'edit' && renderFileInput('Mặt nạ (Tùy chọn)', maskImage, setMaskImage, 'mask-image-upload')}
        
        {mode === 'fusion' && (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-400">Ảnh kết hợp (tối đa 3)</label>
            <div className="grid grid-cols-3 gap-2">
              {fusionImages.map((img, i) => (
                <div key={i} className="relative group">
                  <img src={img} alt={`Fusion image ${i+1}`} className="rounded-lg w-full h-20 object-cover" />
                  <button onClick={() => setFusionImages(imgs => imgs.filter((_, idx) => idx !== i))} className="absolute top-1 right-1 p-1 bg-black/50 rounded-full text-white hover:bg-red-500 transition-colors opacity-0 group-hover:opacity-100">
                    <TrashIcon className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {fusionImages.length < 3 && (
                <label htmlFor="fusion-upload" className="cursor-pointer flex items-center justify-center w-full h-20 border-2 border-gray-600 border-dashed rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors">
                  <UploadIcon className="w-6 h-6 text-gray-500" />
                  <input id="fusion-upload" type="file" multiple className="hidden" accept="image/*" onChange={handleFusionFilesChange} />
                </label>
              )}
            </div>
          </div>
        )}

        <div>
          <label htmlFor="prompt" className="block text-sm font-medium text-gray-400 mb-1">Câu lệnh</label>
          <textarea
            id="prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={
              mode === 'generate' ? "Một chú mèo phi hành gia siêu thực..." :
              mode === 'edit' ? "Thay đổi nền thành một thiên hà" :
              "Một phong cảnh siêu thực"
            }
            className="w-full bg-gray-900 border border-gray-600 rounded-lg p-2 focus:ring-purple-500 focus:border-purple-500 transition"
            rows={4}
            required
          />
        </div>

        {selectedModel?.supportsNegativePrompt && (
          <div>
            <label htmlFor="negative-prompt" className="block text-sm font-medium text-gray-400 mb-1">Câu lệnh phủ định</label>
            <input
              id="negative-prompt"
              type="text"
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              placeholder="ví dụ: mờ, dính logo, xấu"
              className="w-full bg-gray-900 border border-gray-600 rounded-lg p-2 focus:ring-purple-500 focus:border-purple-500 transition"
            />
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label htmlFor="style" className="block text-sm font-medium text-gray-400 mb-1">Phong cách</label>
            <select
              id="style"
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              className="w-full bg-gray-900 border border-gray-600 rounded-lg p-2 focus:ring-purple-500 focus:border-purple-500 transition"
            >
              {STYLES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="aspect-ratio" className="block text-sm font-medium text-gray-400 mb-1">Tỷ lệ khung hình</label>
            <select
              id="aspect-ratio"
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
              className="w-full bg-gray-900 border border-gray-600 rounded-lg p-2 focus:ring-purple-500 focus:border-purple-500 transition"
            >
              {ASPECT_RATIOS.map(ar => <option key={ar} value={ar}>{ar}</option>)}
            </select>
          </div>
        </div>

        {selectedModel?.supportsSeed && (
          <div>
            <label htmlFor="seed" className="block text-sm font-medium text-gray-400 mb-1">Hạt giống (Seed)</label>
            <div className="flex items-center gap-2">
              <input
                id="seed"
                type="number"
                value={seed}
                onChange={(e) => setSeed(Number(e.target.value))}
                className="w-full bg-gray-900 border border-gray-600 rounded-lg p-2 focus:ring-purple-500 focus:border-purple-500 transition"
              />
              <button type="button" onClick={randomizeSeed} className="p-2 bg-gray-700 rounded-lg hover:bg-gray-600 transition" aria-label="Tạo seed ngẫu nhiên">
                🎲
              </button>
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading || !prompt}
          className="w-full flex items-center justify-center gap-2 bg-purple-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
        >
          <GenerateIcon className="w-5 h-5" />
          {isLoading ? 'Đang tạo...' : 'Tạo ảnh'}
        </button>
      </form>
    </div>
  );
};