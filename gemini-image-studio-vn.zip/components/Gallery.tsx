
import React from 'react';
import type { GeneratedImage, GenerationParams } from '../types';
import { ImageCard } from './ImageCard';

interface GalleryProps {
  images: GeneratedImage[];
  onGenerateVariations: (image: GeneratedImage) => void;
  onSelectForEditing: (image: GeneratedImage) => GenerationParams;
  onDeleteImage: (id: string) => void;
  onViewImage: (image: GeneratedImage) => void;
}

export const Gallery: React.FC<GalleryProps> = ({ images, onGenerateVariations, onSelectForEditing, onDeleteImage, onViewImage }) => {
  if (images.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 border-2 border-dashed border-gray-700 rounded-xl p-8">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <h3 className="text-xl font-semibold text-gray-300">Các tác phẩm của bạn sẽ xuất hiện ở đây</h3>
        <p className="mt-1">Sử dụng bảng điều khiển bên trái để bắt đầu tạo ảnh.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-4">
      {images.map((image) => (
        <ImageCard 
          key={image.id} 
          image={image} 
          onGenerateVariations={() => onGenerateVariations(image)}
          onEdit={() => onSelectForEditing(image)}
          onDelete={() => onDeleteImage(image.id)}
          onView={() => onViewImage(image)}
        />
      ))}
    </div>
  );
};