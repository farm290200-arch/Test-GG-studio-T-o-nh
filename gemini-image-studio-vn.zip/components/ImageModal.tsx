
import React from 'react';
import type { GeneratedImage } from '../types';
import { DownloadIcon, XIcon } from './icons';

interface ImageModalProps {
  image: GeneratedImage;
  onClose: () => void;
}

export const ImageModal: React.FC<ImageModalProps> = ({ image, onClose }) => {
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = image.src;
    link.download = `gemini-studio-${image.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div 
      className="fixed inset-0 bg-black/80 backdrop-blur-lg flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="bg-gray-900 border border-gray-700 rounded-xl shadow-2xl w-full max-w-6xl h-full max-h-[90vh] flex flex-col lg:flex-row gap-4 p-4 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute -top-3 -right-3 p-2 bg-gray-800 rounded-full text-white hover:bg-red-500 transition-colors z-10 border border-gray-700"
          aria-label="Đóng"
        >
          <XIcon className="w-6 h-6" />
        </button>

        <div className="flex-grow flex items-center justify-center h-1/2 lg:h-full lg:w-3/4 bg-black rounded-lg overflow-hidden">
          <img 
            src={image.src} 
            alt={image.metadata.prompt} 
            className="max-w-full max-h-full object-contain"
          />
        </div>

        <div className="flex flex-col lg:w-1/4 h-1/2 lg:h-full space-y-4 p-2 overflow-y-auto">
          <h3 className="text-xl font-bold text-purple-400">Chi tiết</h3>
          <div className="text-sm text-gray-300 space-y-2 flex-grow">
            <p><strong>Câu lệnh:</strong> <span className="font-light break-words">{image.metadata.prompt}</span></p>
            {image.metadata.negativePrompt && <p><strong>Câu lệnh phủ định:</strong> <span className="font-light">{image.metadata.negativePrompt}</span></p>}
            <p><strong>Mô hình:</strong> <span className="font-light">{image.metadata.model}</span></p>
            <p><strong>Tỷ lệ khung hình:</strong> <span className="font-light">{image.metadata.aspectRatio}</span></p>
            <p><strong>Hạt giống (Seed):</strong> <span className="font-light">{image.metadata.seed}</span></p>
          </div>
          <button
            onClick={handleDownload}
            className="w-full flex items-center justify-center gap-2 bg-purple-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-purple-700 transition-colors mt-auto"
          >
            <DownloadIcon className="w-5 h-5" />
            Tải ảnh xuống
          </button>
        </div>
      </div>
    </div>
  );
};