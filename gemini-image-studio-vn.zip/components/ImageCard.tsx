import React, { useState } from 'react';
import type { GeneratedImage, AspectRatio } from '../types';
import { DownloadIcon, InfoIcon, EditIcon, VariationsIcon, TrashIcon, ExpandIcon } from './icons';

// Tooltip component to show hints on hover
const Tooltip: React.FC<{ children: React.ReactNode; text: string; }> = ({ children, text }) => {
  return (
    <div className="relative flex items-center group/tooltip">
      {children}
      <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 w-max bg-gray-900 text-white text-xs font-semibold rounded-md py-1.5 px-3 opacity-0 group-hover/tooltip:opacity-100 transition-opacity duration-300 pointer-events-none shadow-lg border border-gray-700 z-10 whitespace-nowrap">
        {text}
        <div className="absolute top-1/2 -translate-y-1/2 right-[-5px] w-0 h-0 border-t-4 border-t-transparent border-b-4 border-b-transparent border-l-4 border-l-gray-700"></div>
      </div>
    </div>
  );
};

interface ImageCardProps {
  image: GeneratedImage;
  onGenerateVariations: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onView: () => void;
}

// Maps aspect ratio values to corresponding Tailwind CSS classes
const aspectRatioClasses: Record<AspectRatio, string> = {
  '1:1': 'aspect-square',
  '16:9': 'aspect-[16/9]',
  '9:16': 'aspect-[9/16]',
  '4:3': 'aspect-[4/3]',
  '3:4': 'aspect-[3/4]',
};

export const ImageCard: React.FC<ImageCardProps> = ({ image, onGenerateVariations, onEdit, onDelete, onView }) => {
  const [showMeta, setShowMeta] = useState(false);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = image.src;
    link.download = `gemini-studio-${image.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const ActionButton: React.FC<{ onClick: () => void, children: React.ReactNode, label: string }> = ({ onClick, children, label }) => (
    <Tooltip text={label}>
      <button
        onClick={onClick}
        aria-label={label}
        className="p-2 bg-black/40 rounded-full text-white hover:bg-purple-600 transition-all duration-200 backdrop-blur-sm"
      >
        {children}
      </button>
    </Tooltip>
  );

  return (
    <div className={`relative group bg-gray-800 rounded-xl overflow-hidden shadow-lg ${aspectRatioClasses[image.metadata.aspectRatio] || 'aspect-square'}`}>
      <img src={image.src} alt={image.metadata.prompt} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
      
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

      <div className="absolute top-2 right-2 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 translate-x-4 group-hover:translate-x-0">
        <ActionButton onClick={onView} label="Phóng to"><ExpandIcon className="w-5 h-5" /></ActionButton>
        <ActionButton onClick={() => setShowMeta(!showMeta)} label="Hiện thông tin"><InfoIcon className="w-5 h-5" /></ActionButton>
        <ActionButton onClick={handleDownload} label="Tải ảnh"><DownloadIcon className="w-5 h-5" /></ActionButton>
        <ActionButton onClick={onGenerateVariations} label="Tạo biến thể"><VariationsIcon className="w-5 h-5" /></ActionButton>
        <ActionButton onClick={onEdit} label="Chỉnh sửa ảnh này"><EditIcon className="w-5 h-5" /></ActionButton>
        <ActionButton onClick={onDelete} label="Xóa ảnh"><TrashIcon className="w-5 h-5" /></ActionButton>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent">
        <p className="text-sm text-white truncate opacity-0 group-hover:opacity-100 transition-opacity duration-300 -translate-y-4 group-hover:translate-y-0">
          {image.metadata.prompt}
        </p>
      </div>

      {showMeta && (
        <div 
          className="absolute inset-0 bg-black/90 backdrop-blur-md p-4 text-xs text-gray-300 overflow-auto flex flex-col z-20"
          onClick={() => setShowMeta(false)}
        >
          <h4 className="font-bold text-base text-purple-400 mb-2">Thông tin chi tiết</h4>
          <div className="space-y-1 overflow-y-auto pr-2">
            <p><strong>Câu lệnh:</strong> <span className="font-light break-words">{image.metadata.prompt}</span></p>
            {image.metadata.negativePrompt && <p><strong>Câu lệnh phủ định:</strong> <span className="font-light">{image.metadata.negativePrompt}</span></p>}
            <p><strong>Mô hình:</strong> <span className="font-light">{image.metadata.model}</span></p>
            <p><strong>Tỷ lệ khung hình:</strong> <span className="font-light">{image.metadata.aspectRatio}</span></p>
            <p><strong>Hạt giống (Seed):</strong> <span className="font-light">{image.metadata.seed}</span></p>
          </div>
           <button onClick={() => setShowMeta(false)} className="mt-auto text-center w-full text-purple-400 font-semibold hover:underline text-sm pt-2">Đóng</button>
        </div>
      )}
    </div>
  );
};