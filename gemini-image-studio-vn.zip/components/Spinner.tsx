
import React from 'react';
import { SparklesIcon } from './icons';

interface SpinnerProps {
  message?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ message }) => {
  return (
    <div className="absolute inset-0 bg-gray-900/80 backdrop-blur-sm flex flex-col items-center justify-center z-10 rounded-xl">
      <div className="relative flex items-center justify-center">
        <div className="w-24 h-24 border-4 border-t-4 border-gray-600 border-t-purple-500 rounded-full animate-spin"></div>
        <SparklesIcon className="absolute w-10 h-10 text-purple-400" />
      </div>
      {message && <p className="mt-4 text-lg font-semibold text-white">{message}</p>}
    </div>
  );
};
