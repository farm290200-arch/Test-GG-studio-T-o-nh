
export type ImageModel = 'gemini-2.5-flash-image' | 'imagen-4.0-generate-001';

export type AspectRatio = '1:1' | '16:9' | '9:16' | '4:3' | '3:4';

export interface Settings {
  model: ImageModel;
}

export interface ImageMetadata {
  prompt: string;
  negativePrompt: string;
  style: string;
  model: ImageModel;
  aspectRatio: AspectRatio;
  seed: number;
}

export interface GeneratedImage {
  id: string;
  src: string;
  metadata: ImageMetadata;
}

export interface GenerationParams {
  prompt: string;
  negativePrompt: string;
  style: string;
  aspectRatio: AspectRatio;
  seed: number;
  initImage: string | null;
  maskImage: string | null;
  fusionImages: string[];
}
