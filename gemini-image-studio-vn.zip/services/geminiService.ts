import { GoogleGenAI, Modality, Part } from "@google/genai";
import type { GenerationParams, ImageModel, GeneratedImage } from "../types";

const getGenAIClient = () => {
    const API_KEY = process.env.API_KEY;
    if (!API_KEY) {
        throw new Error("API Key chưa được định cấu hình. Vui lòng đảm bảo biến môi trường API_KEY đã được thiết lập.");
    }
    return new GoogleGenAI({ apiKey: API_KEY });
};

const handleApiError = (error: any): never => {
  let message = 'Đã xảy ra lỗi không mong muốn.';
  if (error.message) {
    if (error.message.includes('rate limit')) {
      message = 'Bạn đã vượt quá giới hạn yêu cầu. Vui lòng đợi một lát và thử lại.';
    } else if (error.message.includes('safety policy')) {
      message = 'Nội dung được tạo đã bị chính sách an toàn chặn. Vui lòng điều chỉnh câu lệnh của bạn.';
    } else {
      message = error.message;
    }
  }
  throw new Error(message);
};


export async function generateImage(params: GenerationParams & { model: ImageModel }): Promise<string[]> {
  try {
    const ai = getGenAIClient();
    if (params.model === 'imagen-4.0-generate-001') {
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: params.prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: params.aspectRatio,
          negativePrompt: params.negativePrompt,
          seed: params.seed,
        },
      });
      return response.generatedImages.map(img => img.image.imageBytes);
    } else {
      // gemini-2.5-flash-image
      let effectivePrompt = `${params.prompt}. Vui lòng tạo hình ảnh này theo tỷ lệ khung hình ${params.aspectRatio}.`;
      
      if (params.negativePrompt) {
          effectivePrompt += ` Câu lệnh phủ định: ${params.negativePrompt}`;
      }
      const parts: Part[] = [{ text: effectivePrompt }];

      if (params.initImage) {
        parts.unshift({
          inlineData: {
            data: params.initImage.split(',')[1],
            mimeType: 'image/png',
          },
        });
      }
      if (params.maskImage) {
         parts.push({
          inlineData: {
            data: params.maskImage.split(',')[1],
            mimeType: 'image/png',
          },
        });
      }
      if (params.fusionImages.length > 0) {
        params.fusionImages.forEach(img => {
            parts.unshift({
                inlineData: {
                    data: img.split(',')[1],
                    mimeType: 'image/png',
                }
            });
        });
      }

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts },
        config: {
          responseModalities: [Modality.IMAGE],
        },
      });

      const imageParts = response.candidates?.[0]?.content?.parts?.filter(p => p.inlineData);
      if (!imageParts || imageParts.length === 0) {
        throw new Error('Không có hình ảnh nào được tạo. Câu lệnh có thể đã bị chặn.');
      }
      return imageParts.map(p => p.inlineData!.data);
    }
  } catch (error) {
    handleApiError(error);
  }
}


export async function createVariations(image: GeneratedImage, model: ImageModel): Promise<string[]> {
    try {
        const ai = getGenAIClient();
        if (model === 'imagen-4.0-generate-001') {
            const response = await ai.models.generateImages({
                model: 'imagen-4.0-generate-001',
                prompt: image.metadata.prompt,
                config: {
                    numberOfImages: 4,
                    outputMimeType: 'image/png',
                    aspectRatio: image.metadata.aspectRatio,
                    negativePrompt: image.metadata.negativePrompt,
                },
            });
            return response.generatedImages.map(img => img.image.imageBytes);
        } else {
            // gemini-2.5-flash-image doesn't support variations directly. We simulate it with multiple calls.
            let variationPrompt = `Tạo một biến thể của hình ảnh được cung cấp, với chủ đề: ${image.metadata.prompt}. Biến thể phải giữ tỷ lệ khung hình ${image.metadata.aspectRatio}.`;
            if (image.metadata.negativePrompt) {
                variationPrompt += `. Câu lệnh phủ định: ${image.metadata.negativePrompt}`;
            }

            const parts: Part[] = [{ text: variationPrompt },
            {
              inlineData: {
                data: image.src.split(',')[1],
                mimeType: 'image/png'
              }
            }];

            const promises = Array(4).fill(0).map(() => 
              ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: { parts },
                config: {
                    responseModalities: [Modality.IMAGE]
                }
              })
            );

            const responses = await Promise.all(promises);
            const variationSrcs: string[] = [];
            responses.forEach(response => {
                const imagePart = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
                if (imagePart?.inlineData) {
                    variationSrcs.push(imagePart.inlineData.data);
                }
            });

            if (variationSrcs.length === 0) {
                throw new Error("Không thể tạo các biến thể.");
            }
            return variationSrcs;
        }
    } catch (error) {
        handleApiError(error);
    }
}