import type { ImageModel, AspectRatio } from './types';

export const MODELS: { id: ImageModel; name: string; supportsNegativePrompt: boolean; supportsSeed: boolean }[] = [
  { id: 'imagen-4.0-generate-001', name: 'Imagen 4.0', supportsNegativePrompt: true, supportsSeed: true },
  { id: 'gemini-2.5-flash-image', name: 'Gemini 2.5 Flash Image', supportsNegativePrompt: true, supportsSeed: false },
];

export const STYLES: { value: string; label: string }[] = [
  { value: 'Default', label: 'Mặc định' },
  { value: 'Photographic', label: 'Nhiếp ảnh' },
  { value: 'Cinematic', label: 'Điện ảnh' },
  { value: 'Anime', label: 'Anime' },
  { value: 'Fantasy Art', label: 'Nghệ thuật giả tưởng' },
  { value: 'Digital Art', label: 'Nghệ thuật kỹ thuật số' },
  { value: 'Impressionism', label: 'Trường phái ấn tượng' },
  { value: 'Watercolor', label: 'Màu nước' },
  { value: 'Low Poly', label: 'Đa giác thấp' },
  { value: 'Cyberpunk', label: 'Cyberpunk' }
];

export const ASPECT_RATIOS: AspectRatio[] = ['1:1', '16:9', '9:16', '4:3', '3:4'];