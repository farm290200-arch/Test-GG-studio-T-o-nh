export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
};

export const cropImageToAspectRatio = (
  base64Src: string,
  aspectRatio: string
): Promise<string> => {
  return new Promise((resolve, reject) => {
    // Nếu tỷ lệ đã là 1:1, không cần cắt.
    if (aspectRatio === '1:1') {
      resolve(base64Src);
      return;
    }

    const image = new Image();
    image.onload = () => {
      const sourceWidth = image.width;
      const sourceHeight = image.height;
      const sourceAspectRatio = sourceWidth / sourceHeight;

      const [w, h] = aspectRatio.split(':').map(Number);
      const targetAspectRatio = w / h;

      let cropWidth, cropHeight, x, y;

      // Logic này mô phỏng CSS `object-cover`
      if (targetAspectRatio > sourceAspectRatio) {
        // Tỷ lệ đích rộng hơn nguồn, cắt trên và dưới
        cropHeight = sourceWidth / targetAspectRatio;
        cropWidth = sourceWidth;
        x = 0;
        y = (sourceHeight - cropHeight) / 2;
      } else {
        // Tỷ lệ đích cao hơn nguồn, cắt hai bên
        cropWidth = sourceHeight * targetAspectRatio;
        cropHeight = sourceHeight;
        x = (sourceWidth - cropWidth) / 2;
        y = 0;
      }

      const canvas = document.createElement('canvas');
      canvas.width = cropWidth;
      canvas.height = cropHeight;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        return reject(new Error('Không thể lấy context của canvas'));
      }

      ctx.drawImage(
        image,
        x, // tọa độ x nguồn
        y, // tọa độ y nguồn
        cropWidth,  // chiều rộng nguồn
        cropHeight, // chiều cao nguồn
        0, // tọa độ x đích
        0, // tọa độ y đích
        cropWidth,  // chiều rộng đích
        cropHeight  // chiều cao đích
      );

      resolve(canvas.toDataURL('image/png'));
    };
    image.onerror = (err) => reject(err);
    image.src = base64Src;
  });
};
