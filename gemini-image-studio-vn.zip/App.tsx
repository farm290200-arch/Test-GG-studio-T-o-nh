import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ControlPanel } from './components/ControlPanel';
import { Gallery } from './components/Gallery';
import { SettingsModal } from './components/SettingsModal';
import { Spinner } from './components/Spinner';
import { ErrorAlert } from './components/ErrorAlert';
import { ImageModal } from './components/ImageModal';
import type { GeneratedImage, Settings, GenerationParams, ImageModel } from './types';
import { generateImage, createVariations } from './services/geminiService';
import { cropImageToAspectRatio } from './utils/imageUtils';

const App: React.FC = () => {
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [settings, setSettings] = useState<Settings>({
    model: 'gemini-2.5-flash-image',
  });
  const [viewingImage, setViewingImage] = useState<GeneratedImage | null>(null);

  const handleGenerate = useCallback(async (params: GenerationParams) => {
    setIsLoading(true);
    setLoadingMessage('Đang tạo kiệt tác của bạn...');
    setError(null);
    try {
      const newImageSrcs = await generateImage({ ...params, model: settings.model });
      
      const initialDataUrls = newImageSrcs.map(src => `data:image/png;base64,${src}`);
      let finalImageSrcs = initialDataUrls;
      
      // Đối với gemini-flash, API trả về ảnh vuông. Chúng ta cắt nó ở phía client
      // để khớp với tỷ lệ khung hình mong muốn, đảm bảo WYSIWYG cho người dùng.
      if (settings.model === 'gemini-2.5-flash-image' && params.aspectRatio !== '1:1') {
          const cropPromises = initialDataUrls.map(src => cropImageToAspectRatio(src, params.aspectRatio));
          finalImageSrcs = await Promise.all(cropPromises);
      }

      const newImages: GeneratedImage[] = finalImageSrcs.map(src => ({
        id: crypto.randomUUID(),
        src: src,
        metadata: {
          ...params,
          model: settings.model,
        }
      }));
      setImages(prev => [...newImages, ...prev]);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'Đã xảy ra lỗi không xác định. Vui lòng thử lại.');
    } finally {
      setIsLoading(false);
    }
  }, [settings.model]);

  const handleCreateVariations = useCallback(async (image: GeneratedImage) => {
    setIsLoading(true);
    setLoadingMessage(`Đang tạo các biến thể...`);
    setError(null);
    try {
      const variationSrcs = await createVariations(image, settings.model);
      
      const initialDataUrls = variationSrcs.map(src => `data:image/png;base64,${src}`);
      let finalImageSrcs = initialDataUrls;

      // Cũng cắt các biến thể được tạo bởi gemini-flash
      if (settings.model === 'gemini-2.5-flash-image' && image.metadata.aspectRatio !== '1:1') {
          const cropPromises = initialDataUrls.map(src => cropImageToAspectRatio(src, image.metadata.aspectRatio));
          finalImageSrcs = await Promise.all(cropPromises);
      }

      const newImages: GeneratedImage[] = finalImageSrcs.map(src => ({
        id: crypto.randomUUID(),
        src: src,
        metadata: {
          ...image.metadata,
          seed: Math.floor(Math.random() * 1000000), // Gán seed ngẫu nhiên mới cho metadata
          prompt: `Variations of: ${image.metadata.prompt}`
        }
      }));
      setImages(prev => [...newImages, ...prev]);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'Không thể tạo biến thể.');
    } finally {
      setIsLoading(false);
    }
  }, [settings.model]);
  
  const handleDeleteImage = (id: string) => {
    setImages(prev => prev.filter(image => image.id !== id));
  };

  const handleSaveSettings = (newSettings: Settings) => {
    setSettings(newSettings);
    setIsSettingsOpen(false);
  };
  
  const handleSelectForEditing = (image: GeneratedImage): GenerationParams => {
    return {
      prompt: image.metadata.prompt,
      negativePrompt: image.metadata.negativePrompt,
      style: image.metadata.style,
      aspectRatio: image.metadata.aspectRatio,
      seed: image.metadata.seed,
      initImage: image.src,
      maskImage: null,
      fusionImages: [],
    };
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans">
      <Header onSettingsClick={() => setIsSettingsOpen(true)} />
      <main className="flex flex-col lg:flex-row p-4 gap-4">
        <div className="lg:w-1/3 xl:w-1/4 flex-shrink-0">
          <ControlPanel 
            onGenerate={handleGenerate} 
            isLoading={isLoading} 
            model={settings.model}
          />
        </div>
        <div className="flex-grow relative">
          {isLoading && <Spinner message={loadingMessage} />}
          {error && <ErrorAlert message={error} onClose={() => setError(null)} />}
          <Gallery 
            images={images} 
            onGenerateVariations={handleCreateVariations}
            onSelectForEditing={handleSelectForEditing}
            onDeleteImage={handleDeleteImage}
            onViewImage={setViewingImage}
          />
        </div>
      </main>
      {isSettingsOpen && (
        <SettingsModal
          currentSettings={settings}
          onSave={handleSaveSettings}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}
      {viewingImage && (
        <ImageModal 
          image={viewingImage}
          onClose={() => setViewingImage(null)}
        />
      )}
    </div>
  );
};

export default App;